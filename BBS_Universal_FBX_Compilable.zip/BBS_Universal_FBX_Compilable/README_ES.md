# BBS Universal FBX — proyecto para compilar

**Minecraft:** Java 1.20.1  
**Forge objetivo:** 47.4.5  
**Java:** JDK 17  
**Objetivo final:** importar FBX con texturas, esqueletos y animaciones a BBS original y BBS FS, incluido Android/MJ Launcher.

## IMPORTANTE: estado de este ZIP

Este proyecto contiene una base de mod Forge que se puede compilar con el MDK de Forge, además de una clase para reconocer firmas comunes de FBX. **Todavía NO importa ni muestra modelos FBX dentro de BBS.** Los parsers completos y los adaptadores para BBS son trabajo pendiente. No lo presentes como versión funcional del importador.

## Cómo compilar

1. Descarga el **Forge MDK 1.20.1** desde la página oficial: https://files.minecraftforge.net/
2. Extrae el MDK en una carpeta.
3. Copia los archivos de este ZIP encima del MDK, conservando los scripts `gradlew`, `gradlew.bat` y la carpeta `gradle/wrapper` del MDK.
4. Usa JDK 17 y ejecuta en la carpeta del proyecto:
   - Windows: `gradlew.bat build`
   - Linux/macOS/Termux compatible: `./gradlew build`
5. El JAR compilado aparecerá en `build/libs/`.

## Dependencias

- Forge MDK 1.20.1 (incluye Gradle Wrapper).
- JDK 17.
- Las dependencias propias de la versión exacta de BBS FS o BBS original que quieras usar. El JAR de BBS FS que se ha compartido apunta a Fabric, así que usarlo en Forge puede requerir Connector y Forgified Fabric API compatibles. Eso debe verificarse en el entorno de ejecución.
- No se usan bibliotecas nativas de FBX en esta base para evitar incompatibilidades ARM/Android.

## Próximos pasos para el importador real

1. Implementar parser FBX ASCII y binario puro Java.
2. Decodificar geometría, UV, normales, materiales y texturas embebidas/externas.
3. Leer huesos, pesos, bind poses y pistas de animación.
4. Crear una representación interna neutral.
5. Adaptar esa representación a la API de BBS FS y, por separado, a BBS original.
6. Probar en la instalación exacta de MJ Launcher y revisar `latest.log`.

Licencia del esqueleto: MIT.
