package com.kiroytgg.bbsuniversal.fbx;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Detects common FBX file signatures. Does not parse geometry or animation. */
public final class FbxFileProbe {
    private static final byte[] BINARY_MAGIC =
            "Kaydara FBX Binary  ".getBytes(StandardCharsets.US_ASCII);

    private FbxFileProbe() {}

    public enum Kind { BINARY_FBX, ASCII_FBX, UNKNOWN }

    public static Kind inspect(Path path) throws IOException {
        if (!Files.isRegularFile(path) || Files.size(path) < 16) return Kind.UNKNOWN;
        byte[] bytes;
        try (var input = Files.newInputStream(path)) {
            bytes = input.readNBytes(128);
        }
        if (bytes.length >= BINARY_MAGIC.length) {
            boolean match = true;
            for (int i = 0; i < BINARY_MAGIC.length; i++) {
                if (bytes[i] != BINARY_MAGIC[i]) { match = false; break; }
            }
            if (match) return Kind.BINARY_FBX;
        }
        String prefix = new String(bytes, StandardCharsets.US_ASCII);
        if (prefix.contains("; FBX") || prefix.contains("FBXHeaderExtension")
                || prefix.contains("Objects:")) return Kind.ASCII_FBX;
        return Kind.UNKNOWN;
    }
}
