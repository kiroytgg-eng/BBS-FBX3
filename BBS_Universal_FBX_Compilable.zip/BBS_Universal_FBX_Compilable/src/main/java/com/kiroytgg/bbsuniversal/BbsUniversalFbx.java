package com.kiroytgg.bbsuniversal;

import net.minecraftforge.fml.common.Mod;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * BBS Universal FBX development base.
 *
 * This version is a compilable Forge mod scaffold. It does not yet render FBX
 * models inside BBS: the actual parser and BBS-specific adapters remain future
 * implementation work and must be tested against the exact BBS builds.
 */
@Mod(BbsUniversalFbx.MOD_ID)
public final class BbsUniversalFbx {
    public static final String MOD_ID = "bbs_universal_fbx";
    public static final Logger LOGGER = LogManager.getLogger();

    public BbsUniversalFbx() {
        LOGGER.info("BBS Universal FBX development scaffold loaded.");
        LOGGER.warn("FBX import and BBS rendering adapters are not implemented in this build.");
    }
}
